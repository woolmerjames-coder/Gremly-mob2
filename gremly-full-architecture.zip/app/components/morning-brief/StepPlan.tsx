import React, { useMemo } from 'react';
import { View, ScrollView, Pressable, StyleSheet } from 'react-native';
import { Text } from '../../../ui';
import { ShieldOff, Calendar, MoreHorizontal, ChevronLeft } from 'lucide-react-native';
import { BRAND } from '../../../design/brand';
import { BreakHabitCard } from '../../../components/now/BreakHabitCard';
import { TimeBlockSection, type TaskItemData } from './components';
import type { Note } from '../../../lib/types';
import type { CalendarEvent } from '../../../lib/calendar/CalendarClient';

// ═══════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════

interface StepPlanProps {
  capacity: any;
  /** Calendar events visible for this day (non-hidden) */
  calendarEvents: CalendarEvent[];
  keyDatesByBlock: Record<string, Note[]>;
  tasksByBlock: {
    morning: TaskItemData[];
    afternoon: TaskItemData[];
    evening: TaskItemData[];
    flexible: TaskItemData[];
  };
  /** Flexible tasks committed for today (filtered by selection when prioritizing) */
  anytimeTasks: TaskItemData[];
  slottedItemsByBlock: Record<string, any[]>;
  breakHabitsByBlock: Record<string, string[]>;
  collapsedBlocks: Record<string, boolean>;
  hiddenEventIds: string[];
  taskDataById: Record<string, any>;
  today: string;
  scheduleDayName: string;
  onToggleCollapse: (block: string) => void;
  onTaskPress: (task: any) => void;
  onTimePress: (task: any) => void;
  onSlottedTaskPress: (task: any) => void;
  onGapSlotPress: (gap: any, block: 'morning' | 'afternoon' | 'evening') => void;
  onKeyDatePress?: (event: Note) => void;
  onEventQuickAction: (event: Note) => void;
  onFreeMinutesCalculated: (block: string, mins: number) => void;
  getSpaceName: (spaceId: string | null | undefined) => string | undefined;
  organizeMessage?: string | null;
  organizeReasoning?: string[] | null;
  onShowReasoning?: () => void;
  onConfirm: () => void;
  isLoading: boolean;
  onBack?: () => void;
  showBack?: boolean;
}

// ═══════════════════════════════════════════════════════════════════
// Component
// ═══════════════════════════════════════════════════════════════════

export function StepPlan({
  capacity,
  calendarEvents,
  keyDatesByBlock,
  tasksByBlock,
  anytimeTasks,
  slottedItemsByBlock,
  breakHabitsByBlock,
  collapsedBlocks,
  hiddenEventIds,
  taskDataById,
  today,
  scheduleDayName,
  onToggleCollapse,
  onTaskPress,
  onTimePress,
  onSlottedTaskPress,
  onGapSlotPress,
  onKeyDatePress,
  onEventQuickAction,
  onFreeMinutesCalculated,
  getSpaceName,
  organizeMessage,
  organizeReasoning,
  onShowReasoning,
  onConfirm,
  isLoading,
  onBack,
  showBack,
}: StepPlanProps) {
  const eventsByBlock = useMemo(() => {
    const morning: CalendarEvent[] = [];
    const afternoon: CalendarEvent[] = [];
    const evening: CalendarEvent[] = [];

    for (const event of calendarEvents) {
      if (event.isAllDay) continue;
      const startHour = new Date(event.startAt).getHours();
      if (startHour < capacity.blocks.morning.endHour) {
        morning.push(event);
      } else if (startHour < capacity.blocks.day.endHour) {
        afternoon.push(event);
      } else {
        evening.push(event);
      }
    }

    return { morning, afternoon, evening };
  }, [calendarEvents, capacity]);

  return (
    <>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingTop: 16, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Organize feedback — shown if organize ran in Step 4 */}
        {organizeMessage && (
          <View style={styles.organizeFeedback}>
            <Text style={styles.organizeMessage}>{organizeMessage}</Text>
            {(organizeReasoning?.length ?? 0) > 0 && onShowReasoning && (
              <Pressable onPress={onShowReasoning}>
                <Text style={styles.reasoningLink}>Why this plan?</Text>
              </Pressable>
            )}
          </View>
        )}

        {/* ─── SCHEDULE SECTION HEADER ─── */}
        <Text style={styles.scheduleHeader}>{`${scheduleDayName}\u2019S SCHEDULE`}</Text>

        {/* All Day - key date events + break habit awareness card */}
        {(breakHabitsByBlock.allday?.length > 0 || keyDatesByBlock.allday?.length > 0) && (
          <>
            <View style={styles.alldaySection}>
              <View style={styles.alldayHeader}>
                <View style={[styles.alldayBar, { backgroundColor: '#8B7E74' }]} />
                <ShieldOff size={16} color="#8B7E74" />
                <Text style={styles.alldayLabel}>ALL DAY</Text>
              </View>

              {/* All-day key date events */}
              {keyDatesByBlock.allday?.map((keyDate) => (
                <Pressable
                  key={keyDate.id}
                  style={styles.alldayEventRow}
                  onPress={() => onKeyDatePress?.(keyDate)}
                >
                  <Calendar size={14} color="#999999" style={{ marginRight: 10 }} />
                  <Text style={styles.alldayEventTitle} numberOfLines={1}>
                    {keyDate.title || 'Untitled Event'}
                  </Text>
                  <Pressable
                    style={styles.quickActionButton}
                    onPress={(e) => {
                      e.stopPropagation();
                      onEventQuickAction(keyDate);
                    }}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <MoreHorizontal size={16} color="#CCCCCC" />
                  </Pressable>
                </Pressable>
              ))}

              {breakHabitsByBlock.allday?.length > 0 && (
                <BreakHabitCard names={breakHabitsByBlock.allday} />
              )}
            </View>
          </>
        )}

        {/* ─── SCHEDULE TIMELINE ─── */}
        <View>
          {/* Morning */}
          <TimeBlockSection
            capacity={capacity.blocks.morning}
            events={eventsByBlock.morning}
            keyDateEvents={keyDatesByBlock.morning}
            getSpaceName={getSpaceName}
            onKeyDatePress={onKeyDatePress}
            onKeyDateQuickAction={onEventQuickAction}
            tasks={tasksByBlock.morning}
            onTaskPress={onTaskPress}
            onTimePress={onTimePress}
            hiddenEventIds={hiddenEventIds}
            dateContext={today}
            slottedItems={slottedItemsByBlock.morning}
            onGapSlotPress={(gap) => onGapSlotPress(gap, 'morning')}
            onSlottedTaskPress={onSlottedTaskPress}
            taskDataById={taskDataById}
            collapsed={!!collapsedBlocks['morning']}
            onToggleCollapse={() => onToggleCollapse('morning')}
            onFreeMinutesCalculated={onFreeMinutesCalculated}
          />
          {breakHabitsByBlock.morning?.length > 0 && (
            <View style={styles.timelineBreakHabit}>
              <BreakHabitCard names={breakHabitsByBlock.morning} />
            </View>
          )}

          {/* Afternoon */}
          <TimeBlockSection
            capacity={capacity.blocks.day}
            events={eventsByBlock.afternoon}
            keyDateEvents={keyDatesByBlock.day}
            getSpaceName={getSpaceName}
            onKeyDatePress={onKeyDatePress}
            onKeyDateQuickAction={onEventQuickAction}
            tasks={tasksByBlock.afternoon}
            onTaskPress={onTaskPress}
            onTimePress={onTimePress}
            hiddenEventIds={hiddenEventIds}
            dateContext={today}
            slottedItems={slottedItemsByBlock.afternoon}
            onGapSlotPress={(gap) => onGapSlotPress(gap, 'afternoon')}
            onSlottedTaskPress={onSlottedTaskPress}
            taskDataById={taskDataById}
            collapsed={!!collapsedBlocks['day']}
            onToggleCollapse={() => onToggleCollapse('day')}
            onFreeMinutesCalculated={onFreeMinutesCalculated}
          />
          {breakHabitsByBlock.afternoon?.length > 0 && (
            <View style={styles.timelineBreakHabit}>
              <BreakHabitCard names={breakHabitsByBlock.afternoon} />
            </View>
          )}

          {/* Evening */}
          <TimeBlockSection
            capacity={capacity.blocks.evening}
            events={eventsByBlock.evening}
            keyDateEvents={keyDatesByBlock.evening}
            getSpaceName={getSpaceName}
            onKeyDatePress={onKeyDatePress}
            onKeyDateQuickAction={onEventQuickAction}
            tasks={tasksByBlock.evening}
            onTaskPress={onTaskPress}
            onTimePress={onTimePress}
            hiddenEventIds={hiddenEventIds}
            dateContext={today}
            slottedItems={slottedItemsByBlock.evening}
            onGapSlotPress={(gap) => onGapSlotPress(gap, 'evening')}
            onSlottedTaskPress={onSlottedTaskPress}
            taskDataById={taskDataById}
            collapsed={!!collapsedBlocks['evening']}
            onToggleCollapse={() => onToggleCollapse('evening')}
            onFreeMinutesCalculated={onFreeMinutesCalculated}
          />
          {breakHabitsByBlock.evening?.length > 0 && (
            <View style={styles.timelineBreakHabit}>
              <BreakHabitCard names={breakHabitsByBlock.evening} />
            </View>
          )}
        </View>

        {/* ─── ANYTIME (unassigned committed tasks) ─── */}
        {anytimeTasks.length > 0 && (
          <View style={styles.anytimeSection}>
            <View style={styles.anytimeHeader}>
              <View style={[styles.alldayBar, { backgroundColor: BRAND.colors.inkMuted }]} />
              <Text style={styles.anytimeLabel}>ANYTIME</Text>
            </View>
            {anytimeTasks.map((task) => (
              <Pressable
                key={task.id}
                style={({ pressed }) => [
                  styles.anytimeRow,
                  pressed && { backgroundColor: 'rgba(46,85,64,0.04)' },
                ]}
                onPress={() => onTaskPress(task)}
              >
                <View style={styles.anytimeDot} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.anytimeTitle} numberOfLines={1}>
                    {task.title}
                  </Text>
                  {task.estimatedMinutes ? (
                    <Text style={styles.anytimeEst}>{task.estimatedMinutes}m</Text>
                  ) : null}
                </View>
                {task.spaceName ? (
                  <Text style={styles.anytimeSpace} numberOfLines={1}>
                    {task.spaceName}
                  </Text>
                ) : null}
              </Pressable>
            ))}
          </View>
        )}

        {/* Bottom spacing */}
        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Footer */}
      <View style={styles.footerRow}>
        {showBack && onBack && (
          <Pressable
            style={({ pressed }) => [styles.backCircle, pressed && { opacity: 0.6 }]}
            onPress={onBack}
          >
            <ChevronLeft size={20} color={BRAND.colors.charcoalInk} />
          </Pressable>
        )}
        <Pressable
          style={({ pressed }) => [
            styles.looksGoodButton,
            isLoading && { opacity: 0.6 },
            pressed && !isLoading && { backgroundColor: '#AECBB0' },
          ]}
          onPress={onConfirm}
          disabled={isLoading}
        >
          <Text style={styles.looksGoodText}>{isLoading ? 'Saving...' : 'Looks good'}</Text>
        </Pressable>
      </View>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// Styles (copied from MorningBriefSheet.tsx)
// ═══════════════════════════════════════════════════════════════════

const styles = StyleSheet.create({
  scheduleHeader: {
    fontSize: 11,
    fontWeight: '600',
    color: '#888888',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    marginLeft: 36,
    marginBottom: 8,
    marginTop: 4,
  },
  timelineBreakHabit: {
    paddingLeft: 16,
  },
  alldaySection: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 4,
  },
  alldayHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 8,
    gap: 6,
  },
  alldayBar: {
    width: 3,
    height: 16,
    borderRadius: 1.5,
    marginRight: 4,
  },
  alldayLabel: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
    color: '#8B7E74',
  },
  alldayEventRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 4,
  },
  alldayEventTitle: {
    fontSize: 13,
    fontWeight: '500',
    color: '#0E1116',
    flex: 1,
  },
  quickActionButton: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 4,
  },
  organizeFeedback: {
    marginHorizontal: 16,
    marginBottom: 8,
    alignItems: 'center',
    paddingVertical: 8,
  },
  organizeMessage: {
    fontSize: 13,
    color: '#666666',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  reasoningLink: {
    fontSize: 13,
    color: '#2E5540',
    textDecorationLine: 'underline',
    marginTop: 6,
  },
  footerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: BRAND.colors.borderSubtle,
  },
  backCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#E8E6E1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  looksGoodButton: {
    flex: 1,
    backgroundColor: '#BFD8C0',
    height: 48,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  looksGoodText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2E5540',
  },

  // ── Anytime section ─────────────────────────────────────────────
  anytimeSection: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 4,
  },
  anytimeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 8,
    gap: 6,
  },
  anytimeLabel: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
    color: BRAND.colors.inkMuted,
  },
  anytimeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    gap: 10,
  },
  anytimeDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: BRAND.colors.inkMuted,
    opacity: 0.4,
  },
  anytimeTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: BRAND.colors.charcoalInk,
  },
  anytimeEst: {
    fontSize: 12,
    color: BRAND.colors.inkMuted,
    marginTop: 1,
  },
  anytimeSpace: {
    fontSize: 11,
    color: BRAND.colors.inkMuted,
    maxWidth: 80,
  },
});

export default StepPlan;
