# Gremly Hub Export

This export contains the design system and HubScreen-related code.

## Structure

### Design System (`/design/`)
- `brand.ts` - Brand colors and palette
- `tokens.ts` - Design tokens (spacing, typography, etc.)
- `theme.tsx` - Theme configuration
- `styles.ts` - Common styles
- `gradients.ts` - Gradient definitions
- `animations.ts` - Animation presets
- `makeStyles.ts` - Style utility functions
- `z.ts` - Z-index values

### App Design (`/app-design/`)
- `theme.ts` - App-level theme configuration

### Hub Screen (`/HubScreen.tsx`)
The main Hub screen component

### Hub Components (`/components-hub/`)
- `HubHeader.tsx` - Hub screen header
- `AllItemsTable.tsx` - Items table view
- `BrowseBySpaceSection.tsx` - Space browsing section
- `PopularTagsSection.tsx` - Popular tags section
- `ForgetSection.tsx` - Forget/archive section
- `ArchivedLinkRow.tsx` - Archived item row

### Hub Helpers (`/lib-hub/`)
- `hubHelpers.ts` - Hub utility functions

### Selectors
- `hubSelectors.ts` - Hub-related state selectors

### Hub Item Card
- `HubItemCard.tsx` - Item card component

## Lucide Icons

This project uses `lucide-react-native` for icons.

Install: `npm install lucide-react-native`

Usage:
```tsx
import { Search, ChevronRight, Archive } from 'lucide-react-native';

<Search size={20} color="#333" />
```
