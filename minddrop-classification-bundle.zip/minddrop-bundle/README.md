# Mind Drop Classification Bundle

This bundle contains all files related to the Mind Drop feature, its classification pipeline, and data flow.

## Directory Structure

### `app/screens/`
- **CatchAllNotepad.tsx** - Main Mind Drop input screen and recent drops list UI

### `app/components/minddrop/`
- **AnimatedDropCard.tsx** - Animated card component for Mind Drop items

### `lib/minddrop/` - Core Classification Pipeline
- **phase1.ts** - Phase 1: Initial classification (bucket: todo/habit/log)
- **phase2.ts** - Phase 2: AI enrichment (smart title, tags, mood, time estimates)
- **backgroundPrefill.ts** - Background prefill for pending items
- **buildCanonicalFromMindDrop.ts** - Convert Mind Drop to canonical entity
- **heuristicClassify.ts** - Rule-based classification heuristics
- **pipelineStages.ts** - Pipeline stage definitions
- **types.ts** - Mind Drop specific types
- **ids.ts** - ID generation utilities
- **traceId.ts** - Trace ID for debugging
- **invariants.ts** - Pipeline invariants/assertions
- **deleteHelpers.ts** - Deletion helpers
- **logSubtypeTags.ts** - Log subtype tag handling
- **normalizeTodoTitle.ts** - Todo title normalization
- **phase2Validation.ts** - Phase 2 validation
- **photoDrop.ts** - Photo drop handling
- **photoUpload.ts** - Photo upload utilities
- **spacePatterns.ts** - Space detection patterns
- **minddropShared.ts** - Shared utilities

### `lib/cortex/` - AI Classification
- **CortexClient.ts** - Client for Cortex AI service
- **canonicalMap.ts** - Map record types to canonical display types
- **index.ts** - Module exports

### `lib/repo/`
- **supabase.ts** - Supabase repository (CRUD, mapNoteFromDb, etc.)

### `lib/store/`
- **useGremlyStore.ts** - Zustand store (entity management, hydration)

### `lib/supabase/`
- **client.ts** - Supabase client initialization
- **mappers.ts** - Database row mappers

### `lib/` - Types & Schemas
- **types.ts** - Core TypeScript types (Note, Todo, Habit, etc.)
- **schemas.ts** - Zod validation schemas
- **canonicalTypes.ts** - Canonical type definitions and labels

### `lib/shared/`
- **moods.ts** - Mood definitions (13 moods for journal entries)

### `lib/events/`
- **index.ts** - Event bus exports
- **eventBus.ts** - Event bus implementation (entity:created, entity:enriched, etc.)

### `lib/notes/`
- **useRecentLogs.ts** - Hook for fetching recent logs

### `lib/sweep/`
- **types.ts** - Sweep types (SweepCardMeta, etc.)
- **engine.ts** - Sweep engine
- **computeSweepCardMeta.ts** - Compute metadata for sweep cards

### `lib/telemetry/`
- **catchallLogger.ts** - Telemetry for Mind Drop decisions

### `lib/diagnostics/`
- **catchallDebug.ts** - Debug utilities for Mind Drop pipeline

### `lib/lists/`
- **types.ts** - List-related types
- **index.ts** - List utilities

### `hooks/`
- **useMindDropSubmit.ts** - Hook for submitting Mind Drops

### `components/overlay/`
- **UnifiedOverlayV2.tsx** - Entity edit/view overlay

### `minddrop-reference/` - Documentation
- Reference files documenting the Mind Drop architecture

## Data Flow

1. **User Input** → CatchAllNotepad.tsx
2. **Phase 1 Classification** → phase1.ts → Cortex AI determines bucket (todo/habit/log)
3. **Entity Creation** → supabase.ts → Creates entity in database
4. **Phase 2 Enrichment** → phase2.ts → AI extracts smart title, tags, mood, time estimates
5. **Event Emission** → eventBus.ts → entity:created, entity:enriched events
6. **UI Update** → CatchAllNotepad.tsx listens to events, updates local state
7. **Store Sync** → useGremlyStore.ts → Zustand store hydrates from DB

## Key Event Bus Events

- `entity:created` - Fired when entity is created in DB
- `entity:enriched` - Fired when Phase 2 enrichment completes
- `entity:field_updated` - Fired during streaming Phase 2 updates
- `entity:deleted` - Fired when entity is deleted

