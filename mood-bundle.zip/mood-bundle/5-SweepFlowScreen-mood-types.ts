// From app/screens/SweepFlowScreen.tsx (lines 115-200)

// ============================================================================
// Type definitions for Sweep mood handling
// ============================================================================

// Mood value type - aligned with existing journal log moods (DB enum)
type MoodValue = 'happy' | 'neutral' | 'sad' | 'ecstatic' | 'low' | 'tired';

// Extended mood tag type for multi-select (includes new moods not in DB enum)
// ⚠️ Note: anxious, grateful, scattered, hopeful have NO DB mapping!
type MoodTag =
  | 'great'
  | 'good'
  | 'okay'
  | 'low'
  | 'tired'
  | 'anxious'    // ❌ No DB mapping
  | 'grateful'   // ❌ No DB mapping
  | 'scattered'  // ❌ No DB mapping
  | 'hopeful'    // ❌ No DB mapping
  | 'rough';

// ============================================================================
// UI chip options
// ============================================================================

// Mood chip options for Sweep check-in (multi-select)
const SWEEP_MOOD_CHIPS: Array<{ value: MoodTag; label: string }> = [
  { value: 'great', label: 'Great' },
  { value: 'good', label: 'Good' },
  { value: 'okay', label: 'Okay' },
  { value: 'low', label: 'Low' },
  { value: 'tired', label: 'Tired' },
  { value: 'anxious', label: 'Anxious' },
  { value: 'grateful', label: 'Grateful' },
  { value: 'scattered', label: 'Scattered' },
  { value: 'hopeful', label: 'Hopeful' },
  { value: 'rough', label: 'Rough' },
];

// ============================================================================
// DB mapping (CRITICAL - shows what gets lost!)
// ============================================================================

// Map mood tags to DB enum values (for backwards compat)
// ⚠️ Missing: anxious, grateful, scattered, hopeful
const MOOD_TAG_TO_DB: Partial<Record<MoodTag, MoodValue>> = {
  great: 'ecstatic',
  good: 'happy',
  okay: 'neutral',
  low: 'low',
  tired: 'tired',
  rough: 'sad',
  // anxious: ???  - NO MAPPING
  // grateful: ??? - NO MAPPING
  // scattered: ??? - NO MAPPING
  // hopeful: ??? - NO MAPPING
};

// ============================================================================
// Legacy single-select options (reference only)
// ============================================================================

// Legacy mood options (kept for reference)
const SWEEP_MOOD_OPTIONS: Array<{ value: MoodValue; label: string; icon: string }> = [
  { value: 'ecstatic', label: 'Great', icon: 'Sun' },
  { value: 'happy', label: 'Good', icon: 'CheckCircle2' },
  { value: 'neutral', label: 'Okay', icon: 'Minus' },
  { value: 'low', label: 'Low', icon: 'TrendingDown' },
  { value: 'tired', label: 'Tired', icon: 'Moon' },
  { value: 'sad', label: 'Rough', icon: 'Cloud' },
];
