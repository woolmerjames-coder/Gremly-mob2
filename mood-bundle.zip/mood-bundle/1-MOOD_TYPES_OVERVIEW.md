# Mood Types Overview

## Current Mood Type Definitions (Multiple!)

### 1. UnifiedOverlayV2.tsx - MOOD_OPTIONS (line 138)
```typescript
const MOOD_OPTIONS = [
  'great',
  'good',
  'okay',
  'low',
  'tired',
  'anxious',
  'grateful',
  'scattered',
  'hopeful',
  'rough',
] as const;
```
**Used in:** Main overlay mood picker for logs

### 2. lib/types.ts - Note.mood (line 232)
```typescript
mood?: 'ecstatic' | 'happy' | 'neutral' | 'low' | 'sad' | 'tired' | null;
```
**Used in:** Database schema for notes table

### 3. JournalFields.tsx - MoodType (line 32)
```typescript
export type MoodType = 'ecstatic' | 'happy' | 'neutral' | 'low' | 'sad' | 'tired';
```
**Used in:** Journal overlay field component

### 4. overlayV2.state.ts - MoodValue (line 84)
```typescript
export type MoodValue = 'pos' | 'neu' | 'neg';
```
**Used in:** Simplified 3-value mood for state management

### 5. SweepFlowScreen.tsx - MoodTag (line 126)
```typescript
type MoodTag =
  | 'great'
  | 'good'
  | 'okay'
  | 'low'
  | 'tired'
  | 'anxious'
  | 'grateful'
  | 'scattered'
  | 'hopeful'
  | 'rough';
```
**Used in:** Sweep check-in mood picker (multi-select)

### 6. SweepFlowScreen.tsx - MoodValue (line 123)
```typescript
type MoodValue = 'happy' | 'neutral' | 'sad' | 'ecstatic' | 'low' | 'tired';
```
**Used in:** Mapping tags to DB-compatible values

## Mapping Between Systems

### SweepFlowScreen MOOD_TAG_TO_DB mapping (line 167)
```typescript
const MOOD_TAG_TO_DB: Partial<Record<MoodTag, MoodValue>> = {
  great: 'ecstatic',
  good: 'happy',
  okay: 'neutral',
  low: 'low',
  tired: 'tired',
  rough: 'sad',
};
```

## Problem Summary

There are **multiple inconsistent mood type definitions**:
1. UI uses 10 mood options: great, good, okay, low, tired, anxious, grateful, scattered, hopeful, rough
2. DB schema only allows 6: ecstatic, happy, neutral, low, sad, tired
3. Some UI moods (anxious, grateful, scattered, hopeful) have **no DB mapping**

## Files Included in Bundle
- UnifiedOverlayV2-mood-section.tsx - Mood picker UI code
- JournalFields.tsx - Full journal fields component
- overlayV2.state.ts - State management with MoodValue
- types-note-mood.ts - Note interface with mood field
- SweepFlowScreen-mood-types.ts - Sweep mood definitions
