// From components/overlay/overlayV2.state.ts (lines 75-120, 218)

export type FormatKind = 'plain' | 'checkboxes' | 'bullet';
export type PersonLink = { id: string; display: string } | null;

// ⚠️ Different from other mood types! Only 3 values.
export type MoodValue = 'pos' | 'neu' | 'neg';

export type LogSubtypeOverride = 'journal' | 'idea' | 'general' | 'list' | null;

/**
 * V2State - Complete overlay state for all entity types
 *
 * PERSISTED FIELDS (to Supabase via toCreateOrUpdateInput):
 * - baseType: Determines which table (habits/todos/notes)
 * - tags → tags column (JSON array)
 * - stickyTags/tagTombstones → tags_meta column (JSON object)
 * - mood → mood column (notes only)
 * - spaceId → space_id column
 * - format → fmt column (notes only)
 * - reminderAt → date column (notes) or reminders_json (todos/habits)
 * - commitment/commitmentNote/commitmentStartedAt → commitment columns
 * - logSubtypeOverride → subtype column (notes)
 * - logIsPrivate → views.private_journal (notes/journal)
 */
export interface V2State {
  // ... other fields ...
  
  /** Phase L4: Mood for journal logs - uses simplified 3-value enum */
  mood?: MoodValue | null;
  
  // ... other fields ...
}

// Action type for mood
type V2Action =
  // ... other actions ...
  | { type: 'SET_MOOD'; mood: MoodValue | null }
  // ... other actions ...
;
