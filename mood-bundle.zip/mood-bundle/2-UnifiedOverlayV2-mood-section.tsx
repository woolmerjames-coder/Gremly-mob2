// From UnifiedOverlayV2.tsx - Mood picker section
// Lines 135-152, 1492, 5590-5640

// ============================================================================
// MOOD_OPTIONS definition (line 138)
// ============================================================================

const MOOD_OPTIONS = [
  'great',
  'good',
  'okay',
  'low',
  'tired',
  'anxious',
  'grateful',
  'scattered',
  'hopeful',
  'rough',
] as const;

// ============================================================================
// State definition (line 1492)
// ============================================================================

const [mood, setMood] = useState<(typeof MOOD_OPTIONS)[number] | null>(null);

// ============================================================================
// Mood picker UI (lines 5590-5640)
// ============================================================================

// Inside the render:
{/* Mood selector - only for logs/journals (Phase L4) */}
{baseType === 'log' && showJournalUI ? (
  <Box style={{ marginBottom: 0 }}>
    {/* Collapsed or expanded mood picker */}
    {!moodPickerExpanded ? (
      // Collapsed state - show "Mood" button or selected mood
      mood ? (
        <Pressable
          onPress={() => setMoodPickerExpanded(true)}
          style={[
            styles.moodSelectedPill,
            {
              backgroundColor:
                colorMode === 'dark' ? 'rgba(255,255,255,0.15)' : '#D4E8DA',
            },
          ]}
          accessibilityRole="button"
          accessibilityLabel={`Mood: ${mood}. Tap to change.`}
        >
          <Text style={[styles.moodSelectedText, { color: colorMode === 'dark' ? '#fff' : '#2E5540' }]}>
            {mood.charAt(0).toUpperCase() + mood.slice(1)}
          </Text>
        </Pressable>
      ) : (
        <Pressable
          onPress={() => setMoodPickerExpanded(true)}
          style={[
            styles.moodTriggerButton,
            { backgroundColor: colorMode === 'dark' ? 'rgba(255,255,255,0.08)' : '#F0F4F2' },
          ]}
          accessibilityRole="button"
          accessibilityLabel="Add mood"
        >
          <Text style={[styles.moodTriggerText, { color: colorMode === 'dark' ? 'rgba(255,255,255,0.5)' : '#888' }]}>
            Mood
          </Text>
        </Pressable>
      )
    ) : (
      // Expanded state - show all mood options
      <View style={styles.moodPickerExpanded}>
        {MOOD_OPTIONS.map((moodOption) => (
          <Pressable
            key={moodOption}
            onPress={() => {
              setMood(moodOption as any);
              setMoodPickerExpanded(false);
            }}
            style={[
              styles.moodOptionChip,
              mood === moodOption && styles.moodOptionChipActive,
              {
                backgroundColor:
                  mood === moodOption
                    ? colorMode === 'dark'
                      ? 'rgba(255,255,255,0.2)'
                      : '#D4E8DA'
                    : colorMode === 'dark'
                      ? 'rgba(255,255,255,0.08)'
                      : '#F0F4F2',
              },
            ]}
            accessibilityRole="button"
            accessibilityLabel={`Set mood to ${moodOption}`}
          >
            <Text
              style={[
                styles.moodOptionText,
                { color: colorMode === 'dark' ? '#fff' : '#2E5540' },
              ]}
            >
              {moodOption.charAt(0).toUpperCase() + moodOption.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>
    )}
  </View>
) : null}
