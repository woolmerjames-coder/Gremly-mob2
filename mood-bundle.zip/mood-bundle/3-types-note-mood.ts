// From lib/types.ts - Note interface mood field (lines 195-235)

/**
 * Note - journal entry, list, or catch-all note (tags stored as searchable, AI/editable JSON array)
 * When subtype='journal', additional fields (mood, date, reminders, journal_subtype) are used
 * fmt and tags are used for all note types
 */
export interface Note {
  id: ID;
  type: 'note';
  title?: string | null;
  body?: string | null; // Required for creation, but nullable in DB
  subtype: NoteSubtype;
  space_id?: ID | null;
  ai_placed: boolean;
  archived?: boolean; // true when converted to another type
  archived_at?: string | null; // ISO 8601 timestamp when archived
  archived_reason?: string | null; // 'swept' | 'manual' | 'user_deleted_drop' | 'converted'
  why_string?: string | null;
  origin?: 'catchall' | 'space_chat' | 'manual' | 'overlay' | null;
  canonicalType?: CanonicalType | LegacyCanonicalType;
  labels?: string[];
  views?: {
    ai_pending?: boolean;
    ai_failed?: boolean;
    minddrop_stage?: 'pending' | 'classified' | 'prefilled';
    minddrop_prefilled_v1?: boolean;
    [key: string]: any;
  }; // JSONB field for UI state flags
  source_message_id?: string | null;
  drop_id?: string | null;
  created_at: string; // ISO 8601
  updated_at: string; // ISO 8601
  owner_id: ID;

  // Note formatting and organization (Phase 7+) - used for all note types
  fmt?: 'bullets' | 'numbers' | 'checkboxes' | null; // Formatting style
  tags?: string[] | null; // Searchable, AI-editable JSON array persisted in DB

  // Journal-specific fields (Phase 7+) - only used when subtype='journal'
  date?: string | null; // ISO date for journal entry (may differ from created_at)
  
  // ⚠️ DB MOOD ENUM - Only these 6 values are valid in database:
  mood?: 'ecstatic' | 'happy' | 'neutral' | 'low' | 'sad' | 'tired' | null;
  
  reminders?: any[] | null; // ReminderRow[] JSON for journal reminders
  journal_subtype?: 'reflection' | 'gratitude' | 'dream' | 'review' | null; // AI-only journal classification
  tags_meta?: TagsMeta | null;

  // Make Actionable feature fields
  is_favorite?: boolean;
  has_list?: boolean;
  list_items?: Array<{ id: string; text: string; checked: boolean }> | null;

  // Phase 12: Pinned items feature
  is_pinned?: boolean;

  // Sweep tracking
  skipped_in_sweep_at?: string | null;
  swept_at?: string | null; // ISO timestamp when note was reviewed in sweep ("Just Save")
  resurface_at?: string | null; // ISO date when note should reappear in sweep ("Remind Me")
}
