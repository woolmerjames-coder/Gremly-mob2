# Calendar Integration Bundle

This bundle contains key files for understanding the Gremly app architecture to support calendar integration work.

## Contents

### 1. Configuration Files
| File | Description |
|------|-------------|
| `package.json` | Dependencies - No auth libraries like expo-auth-session or react-native-app-auth yet |
| `app.json` | Expo config - scheme: "gremly", deep links configured for Google Sign-In |
| `env.ts` | Typed environment configuration layer with feature flags |

### 2. Navigation Structure
| File | Description |
|------|-------------|
| `RootNavigator.tsx` | Main stack navigator - handles auth flow, onboarding, tab navigation |
| `TabNavigator.tsx` | Bottom tabs: Today, MindDrop, Spaces, Hub |

### 3. State Management (Zustand)
| File | Description |
|------|-------------|
| `useGremlyStore.ts` | Main Zustand store (4397 lines) - uses `create()` with `subscribeWithSelector` middleware |

Key patterns:
- Single store for all entities: todos, habits, notes, spaces, tags, habitProgress
- Optimistic updates with rollback on error
- Supabase sync built-in
- Event bus for cross-component communication

### 4. API Services
| File | Description |
|------|-------------|
| `CortexClient.ts` | API client for Cloudflare worker proxy |
| `supabase-client.ts` | Supabase client initialization with AsyncStorage persistence |

Cortex Worker URL: Set via `EXPO_PUBLIC_CORTEX_URL` environment variable
- Reads from env.ts config layer
- Uses SSE (react-native-sse) for streaming responses
- All AI calls proxied through Cortex (no OpenAI keys in client)

### 5. Today/Now Page (Date-tied Items)
| File | Description |
|------|-------------|
| `TodayScreen.tsx` | Today page component - shows habits, todos, suggestions |
| `NowScreenV1.tsx` | New NOW page (feature flagged) - unified daily view |
| `calendarSelectors.ts` | Calendar view selectors - returns items for a given date |

Key features in NowScreenV1:
- Locked items (committed todos/habits)
- Active items (today's work)
- Recent drops (MindDrop entries)
- Sweep integration
- Morning Brief support

### 6. Existing Calendar Code
| File | Description |
|------|-------------|
| `calendarSelectors.ts` | Hook `useCalendarItemsForDate(dateStr)` - returns todos, habits, journals for a date |

## Missing Components (Not Found)

1. **No wrangler.toml** - Cloudflare worker config not in React Native repo (likely in separate repo)
2. **No expo-auth-session or react-native-app-auth** - No OAuth libraries installed yet
3. **No calendar sync code** - `calendarSelectors.ts` is for internal calendar view only

## Authentication Setup

Current auth:
- Apple Sign-In (`expo-apple-authentication`) 
- Google Sign-In (`@react-native-google-signin/google-signin`)
- Supabase Auth with session persistence via AsyncStorage

URL Schemes configured in `app.json`:
```json
{
  "CFBundleURLSchemes": [
    "com.googleusercontent.apps.81105861621-ombuvivk9f9kifkoji8pgvnfsvstovqi",
    "gremly",
    "com.gremly.mob2"
  ]
}
```

## Key Types

From `calendarSelectors.ts`:
```typescript
type CalendarItemType = 'todo' | 'habit' | 'journal';

interface CalendarItem {
  id: string;
  type: CalendarItemType;
  title: string;
  time: string | null; // HH:mm
  isCompleted: boolean;
  isOverdue: boolean;
  space: { id: string; name: string; theme: string | null } | null;
  tags: string[];
  raw: Todo | Habit | Note;
}
```

## Next Steps for Calendar Integration

1. Install OAuth library (expo-auth-session recommended for Expo)
2. Add Google Calendar API scopes to Google Sign-In config
3. Create CalendarService for Google Calendar API calls
4. Store calendar tokens securely (AsyncStorage or Supabase)
5. Wire calendar events into `useCalendarItemsForDate` selector
6. Display calendar events alongside todos/habits in NowScreenV1
