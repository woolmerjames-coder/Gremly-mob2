# Chat Streaming Files Export

This export contains the core files related to chat functionality in the Gremly app.

## Directory Structure

### Core Chat Screen & Components
- `ChatThreadScreen.tsx` - Main chat screen where messages are rendered (Space Chat)
- `ChatBubble.tsx` - Individual message bubbles component with animations
- `ChatComposer.tsx` - Text input with send functionality
- `ChatActionBar.tsx` - Action bar component (bottom bar)

### Chat State Management
- `useChatMessages.ts` - Hook managing chat message state (send, append, update)
- `useSpaceChatEnhanced.ts` - Orchestration hook combining context, saveable detection, meta-intents
- `useChatContext.ts` - Hook for managing rolling chat context

### AI/Cortex Integration
- `CortexClient.ts` - API client for Supabase Edge Function (calls OpenAI via proxy)
- `index.ts` - Supabase Edge Function cortex-proxy (handles OpenAI API calls server-side)

### Chat Utilities
- `gremlyPersona.ts` - Gremly AI persona and system prompt builder
- `rollingContext.ts` - Rolling context management across chat sessions
- `saveableDetector.ts` - Detects saveable content from AI responses
- `saveableTypes.ts` - Type definitions for saveable detection
- `buildSpaceContext.ts` - Builds context for Space-aware AI conversations
- `conversationMode.ts` - Detects conversation mode (operational vs conversational)
- `quickResponses.ts` - Quick response patterns (no API call needed)

### Store & Types
- `useGremlyStore.ts` - Zustand store managing all app state including chats
- `types.ts` - Core type definitions (SpaceChat, SpaceChatMessage, etc.)

## Key Architecture Notes

1. **Chat Flow**: User types → ChatComposer → handleSend → useChatMessages.sendUserMessage → CortexClient.callSpaceChat → AI response → appendAssistantMessage

2. **No OpenAI Keys in Client**: All AI calls go through cortex-proxy Edge Function which holds the API key

3. **Deferred Chat Creation**: Chats are created lazily when first message is sent (via useChatMessages)

4. **Saveable Detection**: After AI responds, the system analyzes if content is worth saving as todo/habit/note

5. **Rolling Context**: Chat context is persisted and summarized for multi-turn conversations

6. **Response Format**: Currently uses full response (non-streaming) via fetch to OpenAI
