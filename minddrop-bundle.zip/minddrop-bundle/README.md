# Mind Drop Bundle

Comprehensive export of all Mind Drop related files from the Gremly app.

## Directory Structure

```
minddrop-bundle/
├── cloudflare-worker/          # Cortex API (classification, multi-detection)
│   ├── index.js                # Main worker with all endpoints
│   └── wrangler.toml           # Cloudflare config
│
├── lib-minddrop/               # Core Mind Drop processing logic
│   ├── dropProcessor.ts        # Main entry point for processing drops
│   ├── phase1.ts               # Phase 1 classification
│   ├── phase2.ts               # Phase 2 extraction
│   ├── detectMulti.ts          # Multi-entity detection
│   ├── heuristicClassify.ts    # Local heuristic classification
│   ├── types.ts                # TypeScript types
│   ├── pipelineStages.ts       # Pipeline stage definitions
│   ├── buildCanonicalFromMindDrop.ts  # Convert to canonical format
│   └── __tests__/              # Unit tests
│
├── lib-cortex/                 # Cortex client and classification helpers
│   ├── CortexClient.ts         # HTTP client for Cloudflare worker
│   ├── cortexDecide.ts         # Decision logic
│   ├── classify/               # Classification utilities
│   └── thresholds.ts           # Confidence thresholds
│
├── app-screens/                # Main UI screens
│   ├── CatchAllNotepad.tsx     # Main Mind Drop input screen
│   └── __tests__/              # Screen tests
│
├── app-components-minddrop/    # Mind Drop UI components
│   ├── AnimatedDropCard.tsx    # Animated card with spring physics
│   ├── ShimmerPlaceholder.tsx  # Loading shimmer animation
│   └── __tests__/              # Component tests
│
├── hooks/                      # React hooks
│   ├── useMindDropSubmit.ts    # Submit handling
│   ├── useDropRecovery.ts      # Error recovery
│   ├── useOverlayController.ts # Overlay state
│   ├── useUnifiedOverlayController.ts  # Unified overlay
│   └── __tests__/              # Hook tests
│
├── design/                     # Design system
│   ├── animations.ts           # Animation constants (springs, timings)
│   ├── tokens.ts               # Design tokens
│   ├── brand.ts                # Brand colors
│   ├── gradients.ts            # Gradient definitions
│   └── styles.ts               # Shared styles
│
├── contexts/                   # React contexts
│   └── OverlayContext.tsx      # Overlay state context
│
├── minddrop-reference/         # Reference implementations
│   ├── 01-UnifiedDrop-type.ts  # Core type definition
│   ├── 02-AnimatedMindDropCard-JSX.tsx  # Card component reference
│   ├── 03-helper-functions.ts  # Helper utilities
│   ├── 04-card-styles.ts       # Card styling
│   ├── 05-entity-types.ts      # Entity type definitions
│   ├── 06-pipelineStages.ts    # Pipeline stages
│   └── 07-conversion-helpers.ts  # Conversion utilities
│
├── tests/                      # Root-level integration tests
│
├── canonicalTypes.ts           # Canonical type definitions
├── useGremlyStore.ts           # Zustand store
└── EntryCard.tsx               # Entry card component
```

## Key Endpoints (Cloudflare Worker)

- `POST /classify-phase1-v2` - Main classification (todo/habit/log)
- `POST /` with `{"type": "detect-multi"}` - Multi-entity detection
- `POST /` with `{"type": "classify-preparse"}` - Pre-parse analysis

## Architecture

1. **Input**: User text captured in CatchAllNotepad
2. **Multi-detection**: Determines if input contains multiple entities
3. **Pre-parse**: Extracts structural signals (parallel 3-prompt system)
4. **Heuristic mapping**: Fast path for clear cases
5. **Phase 1 LLM**: Bucket classification (todo/habit/log + sub_bucket)
6. **Phase 2 LLM**: Field extraction (title, timing, tags, etc.)
7. **Canonical conversion**: Convert to unified format for storage

## Animation System

Uses React Native Reanimated with spring physics:
- Card entrance: `useSpring` with stiffness/damping
- Shimmer loading: Linear animation with gradient
- State transitions: Interpolated opacity/scale

## Testing

```bash
npm test -- --testPathPattern="minddrop|CatchAll"
```

## Worker Deployment

```bash
cd workers/cortex
npx wrangler deploy --minify
```

Worker URL: `https://gentle-thunder-5854.woolmerjames.workers.dev`
