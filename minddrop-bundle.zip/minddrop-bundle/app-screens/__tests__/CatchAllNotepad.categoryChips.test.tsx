/**
 * Test suite for low-confidence classification category chips
 * Verifies that category chip selection updates existing record instead of creating duplicates
 *
 * DEPRECATED: Tests the legacy Mind Drop pipeline with category chips.
 * With FEATURE_FLAGS.MIND_DROP_V4_ENABLED = true (now the default), the pipeline:
 * - Bypasses category chips entirely
 * - Creates entities directly via useMindDropSubmit hook
 * - Uses Phase 1 classification with no user intervention for confident classifications
 *
 * These tests are skipped until they can be rewritten for the V4 pipeline.
 */

describe.skip('CatchAllNotepad - Category Chips (DEPRECATED - V4 is now default)', () => {
  it('placeholder', () => {
    expect(true).toBe(true);
  });
});

/*
 * Original test file preserved below for reference
 */

import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import { useGlobalOverlay } from '../../../contexts/OverlayContext';
import type { CortexResponse } from '../../../lib/cortex/cortexDecide';

// Force V2 mode (blocking pipeline)
process.env.EXPO_PUBLIC_MIND_DROP_V3_INSTANT = 'off';

type ButtonNode = { props: { accessibilityState?: { disabled?: boolean } } };

// Mock dependencies before imports
const mockRepo = {
  create: jest.fn(),
  update: jest.fn(),
  getById: jest.fn(),
  remove: jest.fn(),
  findNoteBySourceMessageId: jest.fn(),
};

jest.mock('../../../lib/supabase/client', () => ({
  supabase: {
    rpc: jest.fn(),
  },
}));

// eslint-disable-next-line @typescript-eslint/no-var-requires
const { supabase } = require('../../../lib/supabase/client');
const mockSupabaseRpc = supabase.rpc as jest.Mock;

jest.mock('../../../providers/RepoProvider', () => ({
  useRepo: () => mockRepo,
}));

jest.mock('../../../providers/AuthProvider', () => ({
  useAuth: () => ({ user: { id: 'test-user-123' } }),
}));

jest.mock('@react-navigation/native', () => {
  const actual = jest.requireActual('@react-navigation/native');
  return {
    ...actual,
    useNavigation: () => ({ setOptions: jest.fn() }),
  };
});

jest.mock('@react-navigation/elements', () => ({
  useHeaderHeight: () => 100,
}));

const mockDecideWithContext = jest.fn();
jest.mock('../../../providers/CortexProvider', () => ({
  useCortex: () => ({
    decideWithContext: mockDecideWithContext,
  }),
}));

const mockShowActionToast = jest.fn();
jest.mock('../../../src/hooks/useActionToast', () => ({
  useActionToast: () => ({
    showToast: mockShowActionToast,
    Toast: () => null,
  }),
}));

jest.mock('../../../hooks/useUnifiedOverlayController', () => ({
  useUnifiedOverlayController: () => ({
    close: jest.fn(),
  }),
}));

import CatchAllNotepad from '../CatchAllNotepad';

// Skip - V4 pipeline doesn't use category chips
describe.skip('CatchAllNotepad - Category Chips (Original)', () => {
  let createdRecords: any[];

  beforeEach(() => {
    jest.clearAllMocks();
    createdRecords = [];

    const overlay = useGlobalOverlay();
    (overlay.openCreate as jest.Mock).mockClear();
    (overlay.openEdit as jest.Mock).mockClear();

    mockRepo.create.mockImplementation((input) => {
      const record = {
        id: `record-${Date.now()}-${Math.random()}`,
        ...input,
        dropId: input?.dropId ?? '11111111-1111-1111-1111-111111111111',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        drop_id:
          typeof input?.dropId === 'string' ? input.dropId : '11111111-1111-1111-1111-111111111111',
        source_message_id:
          typeof input?.sourceMessageId === 'string' ? input.sourceMessageId : 'minddrop-test-id',
        sourceMessageId: input?.sourceMessageId ?? 'minddrop-test-id',
      };
      createdRecords.push(record);
      return Promise.resolve(record);
    });

    mockRepo.update.mockImplementation(({ id, patch }) => {
      const record = createdRecords.find((r) => r.id === id);
      if (!record) {
        throw new Error(`Record ${id} not found`);
      }
      Object.assign(record, patch);
      return Promise.resolve(record);
    });

    mockRepo.getById.mockImplementation((id) => {
      const record = createdRecords.find((r) => r.id === id);
      if (!record) {
        return Promise.reject(new Error(`Record ${id} not found`));
      }
      return Promise.resolve(record);
    });

    mockRepo.remove.mockResolvedValue(undefined);
    mockRepo.findNoteBySourceMessageId.mockResolvedValue(null);

    mockSupabaseRpc.mockReset();
    mockSupabaseRpc.mockResolvedValue({ data: 'todo-123', error: null });
    process.env.EXPO_PUBLIC_MINDDROP_TOASTS = 'on';
  });

  afterEach(() => {
    delete process.env.EXPO_PUBLIC_MINDDROP_TOASTS;
  });

  const waitForSubmitEnabled = async (button: ButtonNode) => {
    await waitFor(() => {
      expect(button.props.accessibilityState?.disabled).not.toBe(true);
    });
  };

  it('shows category chips when confidence < 0.8', async () => {
    const lowConfidenceResponse: CortexResponse = {
      mode: 'ask',
      confidence: 0.65,
      suggestions: [
        {
          type: 'create.todo',
          label: 'Add as task',
          payload: { name: 'Low confidence item', undefined_due: true },
        },
      ],
      actions: [],
    };

    mockDecideWithContext.mockResolvedValue(lowConfidenceResponse);

    const { getByTestId, getByText } = render(<CatchAllNotepad />);

    const input = getByTestId('minddrop-input');
    const submitButton = getByTestId('minddrop-submit-button');

    fireEvent.changeText(input, 'Maybe do this thing');

    await waitForSubmitEnabled(submitButton);

    fireEvent.press(submitButton);

    await waitFor(() => {
      expect(getByText('Add to To-Do List')).toBeTruthy();
      expect(getByText('Just Save It')).toBeTruthy();
    });

    // Verify only one record created (the unsorted note)
    expect(createdRecords.length).toBe(1);
    expect(createdRecords[0].type).toBe('note');
  });

  it('converts to todo without creating duplicate when "Add to To-Do List" is selected', async () => {
    const lowConfidenceResponse: CortexResponse = {
      mode: 'ask',
      confidence: 0.7,
      suggestions: [
        {
          type: 'create.todo',
          label: 'Add as task',
          payload: { name: 'Low confidence item', undefined_due: true },
        },
      ],
      actions: [],
    };

    mockDecideWithContext.mockResolvedValue(lowConfidenceResponse);

    const { getByTestId, getByText } = render(<CatchAllNotepad />);

    const input = getByTestId('minddrop-input');
    const submitButton = getByTestId('minddrop-submit-button');

    fireEvent.changeText(input, 'Maybe schedule meeting');

    await waitForSubmitEnabled(submitButton);

    fireEvent.press(submitButton);

    await waitFor(() => {
      expect(getByText('Add to To-Do List')).toBeTruthy();
    });

    const todoChip = getByText('Add to To-Do List');
    fireEvent.press(todoChip);

    // Wait for conversion: should create todo + archive original note
    await waitFor(
      () => {
        const createCalls = mockRepo.create.mock.calls;
        expect(createCalls.length).toBeGreaterThanOrEqual(2);
        const todoCreate = createCalls.find((call: any) => call[0].type === 'todo');
        expect(todoCreate).toBeDefined();
      },
      { timeout: 4000 },
    );

    // Verify todo was created
    const todoCreateCall = mockRepo.create.mock.calls.find((call: any) => call[0].type === 'todo');
    expect(todoCreateCall[0]).toMatchObject({
      type: 'todo',
      origin: 'catchall',
    });

    const overlay = useGlobalOverlay();
    expect((overlay.openCreate as jest.Mock).mock.calls.length).toBe(0);
    expect(mockShowActionToast).toHaveBeenCalledWith(
      expect.objectContaining({
        type: 'success',
        content: 'Converted to To-Do ✓',
      }),
    );

    // Verify original note was archived during conversion
    expect(mockRepo.update).toHaveBeenCalledWith(
      expect.objectContaining({
        patch: expect.objectContaining({
          archived: true,
        }),
      }),
    );
    // Only one note initially created (unsorted), then converted to todo
    expect(mockRepo.create).toHaveBeenCalledTimes(2); // unsorted + todo
  });

  it('confirms as log without creating duplicate when "Just Save It" is selected', async () => {
    const lowConfidenceResponse: CortexResponse = {
      mode: 'ask',
      confidence: 0.6,
      suggestions: [
        {
          type: 'create.note',
          label: 'Save as note',
          payload: { title: 'Low confidence item', body: '', subtype: 'idea' },
        },
      ],
      actions: [],
    };

    mockDecideWithContext.mockResolvedValue(lowConfidenceResponse);

    const { getByTestId, getByText } = render(<CatchAllNotepad />);

    const input = getByTestId('minddrop-input');
    const submitButton = getByTestId('minddrop-submit-button');

    fireEvent.changeText(input, 'Random thought about something');

    await waitForSubmitEnabled(submitButton);

    fireEvent.press(submitButton);

    await waitFor(() => {
      expect(getByText('Just Save It')).toBeTruthy();
    });

    const logChip = getByText('Just Save It');
    fireEvent.press(logChip);

    await waitFor(() => {
      // Should have created only the unsorted note and updated it
      expect(createdRecords.length).toBe(1);
      expect(createdRecords[0].type).toBe('note');
      expect(createdRecords[0].archived).toBe(false);
      // New lineage format: "... | origin:ID;source:TYPE"
      expect(createdRecords[0].why_string).toContain('origin:');
      expect(createdRecords[0].why_string).toContain('source:log_confirmation');

      // Verify no duplicate
      expect(mockRepo.create).toHaveBeenCalledTimes(1);
    });
  });

  it('does not show category chips when confidence >= 0.8', async () => {
    const highConfidenceResponse: CortexResponse = {
      mode: 'ask',
      confidence: 0.85,
      suggestions: [
        {
          type: 'create.todo',
          label: 'Add as task',
          payload: { name: 'High confidence item', undefined_due: true },
        },
      ],
      actions: [],
    };

    mockDecideWithContext.mockResolvedValue(highConfidenceResponse);

    const { getByTestId, queryByText } = render(<CatchAllNotepad />);

    const input = getByTestId('minddrop-input');
    const submitButton = getByTestId('minddrop-submit-button');

    fireEvent.changeText(input, 'Buy milk tomorrow');

    await waitForSubmitEnabled(submitButton);

    fireEvent.press(submitButton);

    await waitFor(() => {
      // Should show regular suggestion chips, not category chips
      expect(queryByText('Add to To-Do List')).toBeNull();
      expect(queryByText('Just Save It')).toBeNull();
    });
  });
});
